<?php
/**
 * Frontend Admin List Template
 *
 * @package  Tutor\Certificate\Builder
 * @author   Themeum <support@themeum.com>
 * @license  GPLv2 or later
 * @link     https://www.themeum.com/product/tutor-lms/
 * @since    1.0.0
 */

defined( 'ABSPATH' ) || exit;

use Tutor\Certificate\Builder\Utils;
use TUTOR\Input;
?>

<div class="<?php echo is_admin() ? 'tutor-option-single-item' : ''; ?> tutor-cb-templates-table">
	<?php
	$per_page           = tutor_utils()->get_option( 'pagination_per_page', 10 );
	$current_page       = max( 1, Input::get( 'current_page', 1, Input::TYPE_INT ) );
	$author_id          = tutor_utils()->has_user_role( 'administrator' ) ? null : get_current_user_id();
	$certificates       = Utils::get_certificates( $current_page, $per_page, $author_id, array( 'publish', 'draft' ) );
	$certificates_total = Utils::get_certificates( 0, -1, $author_id, array( 'publish', 'draft' ), true );

	// Load head section if frontend. Admin side has different layout for it.
	if ( ! is_admin() ) {
		require __DIR__ . '/add-certificate-area.php';
	}
	?>

	<?php if ( ! is_admin() ) : ?>
		<div class="tutor-fs-6 color-color-muted tutor-mb-16">
			<?php esc_html_e( 'All Certificates', 'tutor-lms-certificate-builder' ); ?>
		</div>
	<?php endif; ?>

	<?php if ( ! empty( $certificates ) ) : ?>
		<div class="tutor-card">
			<div class="tutor-card-list">
				<?php foreach ( $certificates as $certificate ) : ?>
					<?php
						$row_id           = 'tutor-cb-row-id-' . $certificate->ID;
						$delete_id        = 'tutor-modal-tutor-cb-row-del-' . $certificate->ID;
						$certificate_size = get_post_meta( $certificate->ID, 'tutor_certificate_size', true );
						$size_text        = 'a4' === $certificate_size ? __( 'A4', 'tutor-lms-certificate-builder' ) : __( 'Letter', 'tutor-lms-certificate-builder' );
					?>
					<div id="<?php echo esc_attr( $row_id ); ?>" class="tutor-card-list-item tutor-p-16">
						<div class="tutor-row tutor-align-items-center">
							<div class="tutor-col tutor-d-flex tutor-align-items-center">
								<?php if ( $certificate->thumbnail_url ) : ?>
									<div class="tutor-mr-16">
										<img style="width:90px; height:auto;" src="<?php echo esc_url( $certificate->thumbnail_url ); ?>"/>
									</div>
								<?php endif; ?>
								<div class="tutor-fw-medium tutor-color-black">
									<div class="tutor-fs-6 tutor-mb-4"><?php echo esc_html( $certificate->post_title ); ?></div>
									<div class="tutor-fs-7"><?php esc_html_e( 'Size:', 'tutor-lms-certificate-builder' ); ?> <span class="tutor-color-subdued"><?php echo esc_html( $size_text ); ?></span></div>
								</div>
							</div>

							<div class="tutor-col-auto">
								<div class="tutor-option-field-input d-flex has-btn-after tutor-justify-content-end align-items-center">
									<div class="tutor-form-select-with-icon <?php echo 'draft' === $certificate->post_status ? 'select-default' : 'select-success'; ?>">
										<select class="tutor-cb-status tutor-table-row-status-update" title="<?php esc_html_e( 'Set certificate template status', 'tutor-lms-certificate-builder' ); ?>" data-status_key="status" data-template_id="<?php echo esc_attr( $certificate->ID ); ?>" data-action="tutor_cb_template_status_update">
											<option data-status_class="select-default" value="draft" <?php selected( $certificate->post_status, 'draft' ); ?>>
												<?php esc_html_e( 'Draft', 'tutor-lms-certificate-builder' ); ?>
											</option>
											<option data-status_class="select-success" value="publish" <?php selected( $certificate->post_status, 'publish' ); ?>>
												<?php esc_html_e( 'Published', 'tutor-lms-certificate-builder' ); ?>
											</option>
										</select>
										<i class="icon1 tutor-icon-eye-bold" area-hidden="true"></i>
										<i class="icon2 tutor-icon-eye-slash-bold" area-hidden="true"></i>
									</div>

									<a href="<?php echo esc_url( $certificate->edit_url ); ?>" class="tutor-iconic-btn tutor-ml-16">
										<i class="tutor-icon-edit" area-hidden="true"></i>
									</a>

									<a href="<?php echo esc_url( $certificate->duplicate_url ); ?>" class="tutor-iconic-btn tutor-ml-16">
										<i class="tutor-icon-copy-text" area-hidden="true"></i>
									</a>

									<span data-tutor-modal-target="<?php echo esc_attr( $delete_id ); ?>" class="tutor-iconic-btn tutor-ml-12">
										<i class="tutor-icon-trash-can-line" area-hidden="true"></i>
									</span>
								</div>

								<?php
									tutor_load_template(
										'modal.confirm',
										array(
											'id'      => $delete_id,
											'image'   => 'icon-trash.svg',
											'title'   => __( 'Do You Want to Delete This Certificate?', 'tutor-lms-certificate-builder' ),
											'content' => __( 'Are you sure you want to delete this certificate permanently from the site? Please confirm your choice.', 'tutor-lms-certificate-builder' ),
											'yes'     => array(
												'text'  => __( 'Yes, Delete This', 'tutor-lms-certificate-builder' ),
												'class' => 'tutor-list-ajax-action',
												'attr'  => array( 'data-request_data=\'{"action":"tutor_delete_certificate_template", "certificate_id":"' . $certificate->ID . '"}\'', 'data-delete_element_id="' . $row_id . '"' ),
											),
										)
									);
								?>
							</div>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
		</div>

		<div class="tutor-admin-page-pagination-wrapper tutor-mt-32">
			<?php
				/**
				 * Prepare pagination data & load template
				 */
			if ( $certificates_total > $per_page ) {
				$pagination_data     = array(
					'base'        => '?current_page=%#%',
					'total_items' => $certificates_total,
					'per_page'    => $per_page,
					'paged'       => $current_page,
				);
				$pagination_template = tutor()->path . 'views/elements/pagination.php';
				tutor_load_template_from_custom_path( $pagination_template, $pagination_data );
			}
			?>
		</div>
	<?php else : ?>
		<?php tutor_utils()->tutor_empty_state( __( 'No certificate!', 'tutor-lms-certificate-builder' ) ); ?>
	<?php endif; ?>
</div>
